const Loading = () => {
  return <h1 className="text-center my-3">🌀 Loading...</h1>;
};

export default Loading;
