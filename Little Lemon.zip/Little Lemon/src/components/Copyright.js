const Copyright = () => {
  return (
    <copyright>
        <div className="col-full foot-center">
          <p>&copy; 2024</p>
        </div>
    </copyright>
  );
};

export default Copyright;
